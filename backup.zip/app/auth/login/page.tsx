import LoginForm from "@/app/ui/login-form";


export default function Page() {
    return (
        <div className="flex">
            <LoginForm />            
        </div>
    )
}