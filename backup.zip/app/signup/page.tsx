import SignUpForm from "@/app/ui/signup-form";

export default function Page() {
    return (
        <div className="flex justify-center items-center  w-full">
            <SignUpForm />
        </div>
    )
}