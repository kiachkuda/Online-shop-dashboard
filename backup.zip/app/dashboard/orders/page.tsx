export default function Page() {
    return <div className="">
        Order Page
    </div>
}